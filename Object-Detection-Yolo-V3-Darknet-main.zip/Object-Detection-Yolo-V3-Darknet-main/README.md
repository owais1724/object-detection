![Screenshot (1651)](https://user-images.githubusercontent.com/54833985/129468546-0f4628f0-f372-4932-9b7d-7b8b48784772.png)
# Object-Detection-Yolo-V3-Darknet
Object detection with YOLO V3 in 4 lines of code. Video explanation present on my youtube channel: https://www.youtube.com/watch?v=uc_KTc8VhkQ
